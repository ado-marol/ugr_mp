touch tests//.timeout
CMD=" /home/adolfo/Desktop/ugr_mp/NetBeansProjects/Kmer1/dist/Debug/GNU-Linux/kmer1  < data/zeroPairs.k1in 1> tests//.out7 2>&1"
eval $CMD
rm tests//.timeout
