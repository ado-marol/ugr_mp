touch tests//.timeout
CMD=" /home/adolfo/Desktop/ugr_mp/NetBeansProjects/Kmer0/dist/Debug/GNU-Linux/kmer0  < data/simpleDNA5.k0in 1> tests//.out10 2>&1"
eval $CMD
rm tests//.timeout
