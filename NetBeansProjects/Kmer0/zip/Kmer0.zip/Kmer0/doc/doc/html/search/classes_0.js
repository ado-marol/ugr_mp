var searchData=
[
  ['kmer_13',['Kmer',['../classKmer.html',1,'']]]
];
