var searchData=
[
  ['complementary_1',['complementary',['../classKmer.html#a5573b9ac8221d4fd2f11b30bfc7d0c7a',1,'Kmer']]]
];
