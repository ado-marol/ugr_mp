var searchData=
[
  ['getk_18',['getK',['../classKmer.html#aa800a4d2d89dae1044d13bdc6a42a066',1,'Kmer']]]
];
