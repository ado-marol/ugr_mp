var searchData=
[
  ['size_9',['size',['../classKmer.html#a20154d7f1b00e893ecaf05cdf4221859',1,'Kmer']]]
];
